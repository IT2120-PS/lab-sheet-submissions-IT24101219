# IT24101219
# Piyarathna S.G.D.V
# Probability and Statistics - Lab 06


#Setting the working directory
setwd("C:\\Users\\it24101219\\Desktop\\IT24101219")
#Verifying the working directory
getwd()




# -----------------------------------------------------------

#Question 01
# What is the distribution of X?
# >> X has a binomial distribution with n = 50 with p = 0.85

#What is the probability that at least 47 students passed the test?
#Method 01
pbinom(47,50,0.85, lower.tail = FALSE)
#Method 02
1 - pbinom(47,50,0.85)


# --------------------------------------------------


#Question 02
#What is the random variable (X) for the problem?
# >> Number of calls received in one hour

#What is the distribution of X? 
# >> The random variable x has a Poisson distribution with lambda = 12

#What is the probability that exactly 15 calls are received in an hour?
dpois(15,12)
